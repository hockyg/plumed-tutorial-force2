#!/bin/bash

# Check if the correct number of arguments is provided
if [ "$#" -ne 2 ]; then
	    echo "Usage: $0 <input_file> <output_column_file>"
	        exit 1
fi

input_file="$1"
output_column_file="$2.data"
column_name="$2"

# Find the column index based on the column name
column_index=$(awk -v col="$column_name" 'NR==1 { for (i=1; i<=NF; i++) if ($i == col) print i; }' "$input_file")
column_index=$((column_index - 2))
echo $column_index

# Check if the column name was found
if [ -z "$column_index" ]; then
	    echo "Column '$column_name' not found in the input file."
	        exit 1
fi

rm $output_column_file
# Extract the specified column, excluding lines starting with "#", and save it to the output file
awk -v col="$column_index" '!/^#/ { print $col; }' "$input_file" > "$output_column_file"


echo "Column '$column_name' has been extracted and saved to '$output_column_file'."

