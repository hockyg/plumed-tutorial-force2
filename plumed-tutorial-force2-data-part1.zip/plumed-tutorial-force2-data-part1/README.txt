100ns.tpr generated with Gromacs 2022.3 with command:
gmx grompp -f 100ns.mdp -c prod_200ns.gro -n index.ndx -p topol.top -t prod_200ns.cpt -o 100ns.tpr

prod_200ns refers to a 200 ns unsteered simulation that was performed prior to pulling to ensure that the system was stable.

If you’d like to change the length of the simulation, you can use convert-tpr if you are using the same version of Gromacs. If not, you can change the number of steps in the mdp file and use this for grompp.

To run the simulation, ensure you have loaded your version of Gromacs patched with Plumed. Make a copy of the tpr with a more descriptive name (ex: dS_450pN_vertical.tpr). Put the name of the plumed input file you would like to use in the command line like so:
gmx mdrun -deffnm dS_450pN_vertical -plumed dS_450pN_vertical.dat

